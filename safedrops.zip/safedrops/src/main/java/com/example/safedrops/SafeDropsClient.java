package com.example.safedrops;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;

public class SafeDropsClient implements ClientModInitializer {

    // сколько тиков после убийства нельзя бить кристалл (60 тиков = 3 секунды)
    private static final int LOCK_TICKS = 60;
    // сколько тиков после удара по игроку он считается "нашей целью"
    private static final int TARGET_MEMORY = 100;

    private PlayerEntity lastTarget;
    private int targetAge;
    private int lockLeft;

    @Override
    public void onInitializeClient() {
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (!world.isClient()) return ActionResult.PASS;

            if (entity instanceof PlayerEntity target) {
                lastTarget = target;
                targetAge = 0;
            } else if (entity instanceof EndCrystalEntity && lockLeft > 0) {
                player.sendMessage(Text.literal("Кристалл заблокирован"), true);
                return ActionResult.FAIL;
            }
            return ActionResult.PASS;
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (lockLeft > 0) lockLeft--;

            if (lastTarget != null) {
                targetAge++;
                if (lastTarget.isDead() || lastTarget.getHealth() <= 0) {
                    lockLeft = LOCK_TICKS;
                    lastTarget = null;
                } else if (targetAge > TARGET_MEMORY || lastTarget.isRemoved()) {
                    lastTarget = null;
                }
            }
        });
    }
}
